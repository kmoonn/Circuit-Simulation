-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: neri_rd
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gen_table`
--

DROP TABLE IF EXISTS `gen_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gen_table` (
  `table_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(500) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '表描述',
  `sub_table_name` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '关联子表的表名',
  `sub_table_fk_name` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表关联的外键名',
  `class_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '实体类名称',
  `tpl_category` varchar(200) COLLATE utf8mb4_general_ci DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `tpl_web_type` varchar(30) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '前端模板类型（element-ui模版 element-plus模版）',
  `package_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) COLLATE utf8mb4_general_ci DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='代码生成业务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gen_table`
--

LOCK TABLES `gen_table` WRITE;
/*!40000 ALTER TABLE `gen_table` DISABLE KEYS */;
INSERT INTO `gen_table` VALUES (1,'neri_rduser','研发人员信息表',NULL,NULL,'NeriRduser','crud','lmw','cn.bpeg.neri.manage','manage','rduser','研发人员','YouthTry','0','/','{\"parentMenuId\":0}','admin','2025-11-05 17:50:19','','2025-11-06 15:07:02',NULL),(2,'neri_project','产品研发信息表',NULL,NULL,'NeriProject','crud','lmw','cn.bpeg.neri.manage','manage','project','产品研发','YouthTry','0','/','{}','admin','2025-11-06 15:07:43','','2025-11-06 15:12:29',NULL),(3,'neri_division','',NULL,NULL,'NeriDivision','crud','','cn.bpeg.neri.manage','manage','division',NULL,'YouthTry','0','/',NULL,'admin','2025-11-16 19:15:26','',NULL,NULL),(4,'neri_division_progress','',NULL,NULL,'NeriDivisionProgress','crud','','cn.bpeg.neri.manage','manage','progress',NULL,'YouthTry','0','/',NULL,'admin','2025-11-16 19:15:27','',NULL,NULL),(5,'neri_project_division','',NULL,NULL,'NeriProjectDivision','crud','','cn.bpeg.neri.manage','manage','division',NULL,'YouthTry','0','/',NULL,'admin','2025-11-16 19:15:27','',NULL,NULL);
/*!40000 ALTER TABLE `gen_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gen_table_column`
--

DROP TABLE IF EXISTS `gen_table_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gen_table_column` (
  `column_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` bigint DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) COLLATE utf8mb4_general_ci DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典类型',
  `sort` int DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='代码生成业务表字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gen_table_column`
--

LOCK TABLES `gen_table_column` WRITE;
/*!40000 ALTER TABLE `gen_table_column` DISABLE KEYS */;
INSERT INTO `gen_table_column` VALUES (1,1,'rduser_id','','bigint','Long','rduserId','1','0','0','1',NULL,NULL,NULL,'EQ','input','',1,'admin','2025-11-05 17:50:19','','2025-11-06 15:07:02'),(3,1,'position_category','','varchar(50)','String','positionCategory','0','0','0','1','1','1','1','LIKE','input','',2,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:03'),(4,1,'tech_title','','varchar(50)','String','techTitle','0','0','0','1','1','1','1','LIKE','input','',3,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:03'),(6,1,'graduate_school','','varchar(100)','String','graduateSchool','0','0','0','1','1','1','1','EQ','input','',4,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:03'),(7,1,'major','','varchar(50)','String','major','0','0','0','1','1','1','1','LIKE','input','',5,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:03'),(8,1,'education','','varchar(50)','String','education','0','0','0','1','1','1','1','EQ','select','',6,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:03'),(9,1,'birth_date','','date','Date','birthDate','0','0','0','1','1','1','1','EQ','datetime','',7,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:04'),(10,1,'join_date','','date','Date','joinDate','0','0','0','1','1','1','1','EQ','datetime','',8,'admin','2025-11-05 17:50:20','','2025-11-06 15:07:04'),(11,1,'political_status','','varchar(50)','String','politicalStatus','0','0','0','1','1','1','1','EQ','select','',9,'admin','2025-11-05 17:50:21','','2025-11-06 15:07:04'),(12,2,'project_id','项目ID','int','Integer','projectId','1','1','0','0',NULL,NULL,NULL,'EQ','input','',1,'admin','2025-11-06 15:07:43','','2025-11-06 15:12:30'),(13,2,'project_name','项目名称','varchar(200)','String','projectName','0','0','1','1','1','1','1','LIKE','input','',2,'admin','2025-11-06 15:07:43','','2025-11-06 15:12:30'),(14,2,'project_type_id','项目类型ID','int','Integer','projectTypeId','0','0','1','1','1','1','1','EQ','select','',3,'admin','2025-11-06 15:07:43','','2025-11-06 15:12:30'),(15,2,'leader_id','项目负责人','bigint','Long','leaderId','0','0','1','1','1','1','1','LIKE','input','',4,'admin','2025-11-06 15:07:43','','2025-11-06 15:12:30'),(16,2,'specialist_id','项目专责人','bigint','Long','specialistId','0','0','1','1','1','1','1','LIKE','input','',5,'admin','2025-11-06 15:07:44','','2025-11-06 15:12:30'),(17,2,'start_date','开始时间','date','Date','startDate','0','0','1','1','1','1','0','EQ','datetime','',6,'admin','2025-11-06 15:07:44','','2025-11-06 15:12:31'),(18,2,'end_date','结束时间','date','Date','endDate','0','0','0','1','1','1','0','EQ','datetime','',7,'admin','2025-11-06 15:07:44','','2025-11-06 15:12:31'),(19,2,'contract_file','项目合同','varchar(255)','String','contractFile','0','0','0','1','1','1','0','EQ','fileUpload','',8,'admin','2025-11-06 15:07:44','','2025-11-06 15:12:31'),(20,2,'tender_file','技术规范','varchar(255)','String','tenderFile','0','0','0','1','1','1','0','EQ','fileUpload','',9,'admin','2025-11-06 15:07:45','','2025-11-06 15:12:32'),(21,3,'division_id',NULL,'int','Long','divisionId','1','1','0','1',NULL,NULL,NULL,'EQ','input','',1,'admin','2025-11-16 19:15:27','',NULL),(22,3,'major_name',NULL,'varchar(100)','String','majorName','0','0','1','1','1','1','1','LIKE','input','',2,'admin','2025-11-16 19:15:27','',NULL),(23,3,'division_leader_id',NULL,'bigint','Long','divisionLeaderId','0','0','0','1','1','1','1','EQ','input','',3,'admin','2025-11-16 19:15:27','',NULL),(24,3,'start_date',NULL,'date','Date','startDate','0','0','0','1','1','1','1','EQ','datetime','',4,'admin','2025-11-16 19:15:27','',NULL),(25,3,'planned_end_date',NULL,'date','Date','plannedEndDate','0','0','0','1','1','1','1','EQ','datetime','',5,'admin','2025-11-16 19:15:27','',NULL),(26,4,'division_id','','int','Long','divisionId','0','0','0','1','1','1','1','EQ','input','',1,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:37'),(27,4,'progress_id','','int','Long','progressId','1','1','0','1',NULL,NULL,NULL,'EQ','input','',2,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:37'),(28,4,'progress_file','','varchar(255)','String','progressFile','0','0','0','1','1','1','1','EQ','fileUpload','',3,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:38'),(29,4,'submit_date','','date','Date','submitDate','0','0','0','1','1','1','1','EQ','datetime','',4,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:38'),(30,5,'project_id','','int','Long','projectId','1','0','0','1',NULL,NULL,NULL,'EQ','input','',1,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:08'),(31,5,'division_id','','int','Long','divisionId','1','0','0','1',NULL,NULL,NULL,'EQ','input','',2,'admin','2025-11-16 19:15:27','','2025-11-16 21:13:08'),(32,4,'progress',NULL,'decimal(10,0)','Long','progress','0','0','0','1','1','1','1','EQ','input','',5,'','2025-11-16 21:13:38','',NULL);
/*!40000 ALTER TABLE `gen_table_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_division`
--

DROP TABLE IF EXISTS `neri_division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_division` (
  `division_id` int NOT NULL AUTO_INCREMENT,
  `major_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `division_leader_id` bigint DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `planned_end_date` date DEFAULT NULL,
  PRIMARY KEY (`division_id`) USING BTREE,
  KEY `div_leader_id` (`division_leader_id`),
  CONSTRAINT `neri_division_ibfk_1` FOREIGN KEY (`division_leader_id`) REFERENCES `neri_rduser` (`rduser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_division`
--

LOCK TABLES `neri_division` WRITE;
/*!40000 ALTER TABLE `neri_division` DISABLE KEYS */;
/*!40000 ALTER TABLE `neri_division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_division_progress`
--

DROP TABLE IF EXISTS `neri_division_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_division_progress` (
  `division_id` int DEFAULT NULL,
  `progress_id` int NOT NULL AUTO_INCREMENT,
  `progress_file` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `submit_date` date DEFAULT NULL,
  `progress` float DEFAULT NULL,
  PRIMARY KEY (`progress_id`),
  KEY `div_id` (`division_id`),
  CONSTRAINT `neri_division_progress_ibfk_1` FOREIGN KEY (`division_id`) REFERENCES `neri_division` (`division_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_division_progress`
--

LOCK TABLES `neri_division_progress` WRITE;
/*!40000 ALTER TABLE `neri_division_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `neri_division_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_project`
--

DROP TABLE IF EXISTS `neri_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_project` (
  `project_id` int NOT NULL AUTO_INCREMENT,
  `project_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `project_type_id` int DEFAULT NULL,
  `leader_id` bigint DEFAULT NULL,
  `specialist_id` bigint DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `contract_file` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tender_file` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`project_id`) USING BTREE,
  KEY `pro_type_id` (`project_type_id`),
  KEY `leader_id` (`leader_id`),
  KEY `specialist_id` (`specialist_id`),
  CONSTRAINT `neri_project_ibfk_1` FOREIGN KEY (`project_type_id`) REFERENCES `neri_project_type` (`project_type_id`),
  CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`),
  CONSTRAINT `neri_project_ibfk_3` FOREIGN KEY (`specialist_id`) REFERENCES `neri_rduser` (`rduser_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_project`
--

LOCK TABLES `neri_project` WRITE;
/*!40000 ALTER TABLE `neri_project` DISABLE KEYS */;
INSERT INTO `neri_project` VALUES (18,'测试时',1,4,102,'2025-11-14','2025-11-21','/profile/upload/2025/11/15/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251115224251A011.pdf,/profile/upload/2025/11/16/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251116000835A001.pdf','/profile/upload/2025/11/15/《公共数据资源授权运营实施规范（试行）》.pdf_20251115224251A013.pdf'),(20,'测试项目',2,4,102,'2025-11-18','2025-11-26','/profile/upload/2025/11/18/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251118095658A001.pdf,/profile/upload/2025/11/18/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251118095658A002.pdf','/profile/upload/2025/11/18/《公共数据资源登记管理暂行办法》.pdf_20251118095658A003.pdf,/profile/upload/2025/11/18/《公共数据资源授权运营实施规范（试行）》.pdf_20251118095658A004.pdf'),(21,'测试',3,102,4,'2025-11-18',NULL,'/profile/upload/2025/11/18/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251118100052A005.pdf','/profile/upload/2025/11/18/公共数据授权运营发展洞察_20251118100052A007.pdf');
/*!40000 ALTER TABLE `neri_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_project_division`
--

DROP TABLE IF EXISTS `neri_project_division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_project_division` (
  `project_id` int NOT NULL,
  `division_id` int NOT NULL,
  PRIMARY KEY (`project_id`,`division_id`) USING BTREE,
  KEY `division_id` (`division_id`),
  CONSTRAINT `neri_project_division_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `neri_project` (`project_id`),
  CONSTRAINT `neri_project_division_ibfk_2` FOREIGN KEY (`division_id`) REFERENCES `neri_division` (`division_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_project_division`
--

LOCK TABLES `neri_project_division` WRITE;
/*!40000 ALTER TABLE `neri_project_division` DISABLE KEYS */;
/*!40000 ALTER TABLE `neri_project_division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_project_type`
--

DROP TABLE IF EXISTS `neri_project_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_project_type` (
  `project_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`project_type_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_project_type`
--

LOCK TABLES `neri_project_type` WRITE;
/*!40000 ALTER TABLE `neri_project_type` DISABLE KEYS */;
INSERT INTO `neri_project_type` VALUES (1,'测试','测试测试'),(2,'测试类型','测试测试'),(3,'项目类型',''),(4,'测试下',''),(5,'项目测试','');
/*!40000 ALTER TABLE `neri_project_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neri_rduser`
--

DROP TABLE IF EXISTS `neri_rduser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `neri_rduser` (
  `rduser_id` bigint NOT NULL,
  `position_category` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tech_title` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `graduate_school` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `major` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `education` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `political_status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`rduser_id`) USING BTREE,
  CONSTRAINT `neri_rduser_ibfk_1` FOREIGN KEY (`rduser_id`) REFERENCES `sys_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='研发人员信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neri_rduser`
--

LOCK TABLES `neri_rduser` WRITE;
/*!40000 ALTER TABLE `neri_rduser` DISABLE KEYS */;
INSERT INTO `neri_rduser` VALUES (4,'软件','高级工程师','北京大学','电气专业','本科','2002-11-01','2025-11-03','中共党员'),(102,'软件','中级工程师','武汉理工大学','信息工程','硕士','2025-11-06','2025-11-10','共青团员');
/*!40000 ALTER TABLE `neri_rduser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `config_id` int NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='参数配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES (1,'主框架页-默认皮肤样式名称','sys.index.skinName','skin-blue','Y','admin','2025-10-31 17:51:47','',NULL,'蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow'),(2,'用户管理-账号初始密码','sys.user.initPassword','123456','Y','admin','2025-10-31 17:51:47','',NULL,'初始化密码 123456'),(3,'主框架页-侧边栏主题','sys.index.sideTheme','theme-dark','Y','admin','2025-10-31 17:51:47','',NULL,'深色主题theme-dark，浅色主题theme-light'),(5,'账号自助-是否开启用户注册功能','sys.account.registerUser','false','Y','admin','2025-10-31 17:51:47','',NULL,'是否开启注册用户功能（true开启，false关闭）'),(6,'用户登录-黑名单列表','sys.login.blackIPList','','Y','admin','2025-10-31 17:51:47','',NULL,'设置登录IP黑名单限制，多个匹配项以;分隔，支持匹配（*通配、网段）'),(7,'用户管理-初始密码修改策略','sys.account.initPasswordModify','1','Y','admin','2025-10-31 17:51:47','',NULL,'0：初始密码修改策略关闭，没有任何提示，1：提醒用户，如果未修改初始密码，则在登录时就会提醒修改密码对话框'),(8,'用户管理-账号密码更新周期','sys.account.passwordValidateDays','0','Y','admin','2025-10-31 17:51:47','',NULL,'密码更新周期（填写数字，数据初始化值为0不限制，若修改必须为大于0小于365的正整数），如果超过这个周期登录系统时，则在登录时就会提醒修改密码对话框');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dept`
--

DROP TABLE IF EXISTS `sys_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dept` (
  `dept_id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` bigint DEFAULT '0' COMMENT '父部门id',
  `ancestors` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '部门名称',
  `order_num` int DEFAULT '0' COMMENT '显示顺序',
  `leader` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '邮箱',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dept`
--

LOCK TABLES `sys_dept` WRITE;
/*!40000 ALTER TABLE `sys_dept` DISABLE KEYS */;
INSERT INTO `sys_dept` VALUES (100,0,'0','新能源研发总院',0,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','admin','2025-11-18 09:59:08'),(101,100,'0,100','部门一',1,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','',NULL),(102,100,'0,100','部门二',2,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','',NULL),(103,101,'0,100,101','研发部门',1,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','',NULL),(104,101,'0,100,101','市场部门',2,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','',NULL),(105,101,'0,100,101','测试部门',3,NULL,'15888888888','ry@qq.com','0','0','admin','2025-10-31 17:51:47','',NULL);
/*!40000 ALTER TABLE `sys_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_data`
--

DROP TABLE IF EXISTS `sys_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='字典数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_data`
--

LOCK TABLES `sys_dict_data` WRITE;
/*!40000 ALTER TABLE `sys_dict_data` DISABLE KEYS */;
INSERT INTO `sys_dict_data` VALUES (1,1,'男','0','sys_user_sex','','','Y','0','admin','2025-10-31 17:51:47','',NULL,'性别男'),(2,2,'女','1','sys_user_sex','','','N','0','admin','2025-10-31 17:51:47','',NULL,'性别女'),(3,3,'未知','2','sys_user_sex','','','N','0','admin','2025-10-31 17:51:47','',NULL,'性别未知'),(4,1,'显示','0','sys_show_hide','','primary','Y','0','admin','2025-10-31 17:51:47','',NULL,'显示菜单'),(5,2,'隐藏','1','sys_show_hide','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'隐藏菜单'),(6,1,'正常','0','sys_normal_disable','','primary','Y','0','admin','2025-10-31 17:51:47','',NULL,'正常状态'),(7,2,'停用','1','sys_normal_disable','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'停用状态'),(12,1,'是','Y','sys_yes_no','','primary','Y','0','admin','2025-10-31 17:51:47','',NULL,'系统默认是'),(13,2,'否','N','sys_yes_no','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'系统默认否'),(14,1,'通知','1','sys_notice_type','','warning','Y','0','admin','2025-10-31 17:51:47','',NULL,'通知'),(15,2,'公告','2','sys_notice_type','','success','N','0','admin','2025-10-31 17:51:47','',NULL,'公告'),(16,1,'正常','0','sys_notice_status','','primary','Y','0','admin','2025-10-31 17:51:47','',NULL,'正常状态'),(17,2,'关闭','1','sys_notice_status','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'关闭状态'),(18,99,'其他','0','sys_oper_type','','info','N','0','admin','2025-10-31 17:51:47','',NULL,'其他操作'),(19,1,'新增','1','sys_oper_type','','info','N','0','admin','2025-10-31 17:51:47','',NULL,'新增操作'),(20,2,'修改','2','sys_oper_type','','info','N','0','admin','2025-10-31 17:51:47','',NULL,'修改操作'),(21,3,'删除','3','sys_oper_type','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'删除操作'),(22,4,'授权','4','sys_oper_type','','primary','N','0','admin','2025-10-31 17:51:47','',NULL,'授权操作'),(23,5,'导出','5','sys_oper_type','','warning','N','0','admin','2025-10-31 17:51:47','',NULL,'导出操作'),(24,6,'导入','6','sys_oper_type','','warning','N','0','admin','2025-10-31 17:51:47','',NULL,'导入操作'),(25,7,'强退','7','sys_oper_type','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'强退操作'),(26,8,'生成代码','8','sys_oper_type','','warning','N','0','admin','2025-10-31 17:51:47','',NULL,'生成操作'),(27,9,'清空数据','9','sys_oper_type','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'清空操作'),(28,1,'成功','0','sys_common_status','','primary','N','0','admin','2025-10-31 17:51:47','',NULL,'正常状态'),(29,2,'失败','1','sys_common_status','','danger','N','0','admin','2025-10-31 17:51:47','',NULL,'停用状态'),(100,1,'本科','本科','neri_education',NULL,'default','N','0','admin','2025-11-06 13:01:10','',NULL,NULL),(101,2,'硕士','硕士','neri_education',NULL,'default','N','0','admin','2025-11-06 13:01:30','admin','2025-11-06 13:01:45',NULL),(102,3,'博士','博士','neri_education',NULL,'default','N','0','admin','2025-11-06 13:02:00','',NULL,NULL),(103,1,'群众','群众','neri_political_status',NULL,'default','N','0','admin','2025-11-06 13:04:52','',NULL,NULL),(104,2,'共青团员','共青团员','neri_political_status',NULL,'default','N','0','admin','2025-11-06 13:04:52','',NULL,NULL),(105,3,'预备党员','预备党员','neri_political_status',NULL,'default','N','0','admin','2025-11-06 13:04:52','',NULL,NULL),(106,4,'中共党员','中共党员','neri_political_status',NULL,'default','N','0','admin','2025-11-06 13:04:52','',NULL,NULL);
/*!40000 ALTER TABLE `sys_dict_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_type`
--

DROP TABLE IF EXISTS `sys_dict_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='字典类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_type`
--

LOCK TABLES `sys_dict_type` WRITE;
/*!40000 ALTER TABLE `sys_dict_type` DISABLE KEYS */;
INSERT INTO `sys_dict_type` VALUES (1,'用户性别','sys_user_sex','0','admin','2025-10-31 17:51:47','',NULL,'用户性别列表'),(2,'菜单状态','sys_show_hide','0','admin','2025-10-31 17:51:47','',NULL,'菜单状态列表'),(3,'系统开关','sys_normal_disable','0','admin','2025-10-31 17:51:47','',NULL,'系统开关列表'),(6,'系统是否','sys_yes_no','0','admin','2025-10-31 17:51:47','',NULL,'系统是否列表'),(7,'通知类型','sys_notice_type','0','admin','2025-10-31 17:51:47','',NULL,'通知类型列表'),(8,'通知状态','sys_notice_status','0','admin','2025-10-31 17:51:47','',NULL,'通知状态列表'),(9,'操作类型','sys_oper_type','0','admin','2025-10-31 17:51:47','',NULL,'操作类型列表'),(10,'系统状态','sys_common_status','0','admin','2025-10-31 17:51:47','',NULL,'登录状态列表'),(100,'学历','neri_education','0','admin','2025-11-06 13:00:38','',NULL,NULL),(101,'政治面貌','neri_political_status','0','admin','2025-11-06 13:04:22','',NULL,NULL);
/*!40000 ALTER TABLE `sys_dict_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_logininfor`
--

DROP TABLE IF EXISTS `sys_logininfor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_logininfor` (
  `info_id` bigint NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '用户账号',
  `ipaddr` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '提示消息',
  `login_time` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`),
  KEY `idx_sys_logininfor_s` (`status`),
  KEY `idx_sys_logininfor_lt` (`login_time`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统访问记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_logininfor`
--

LOCK TABLES `sys_logininfor` WRITE;
/*!40000 ALTER TABLE `sys_logininfor` DISABLE KEYS */;
INSERT INTO `sys_logininfor` VALUES (100,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','1','验证码已失效','2025-10-31 18:35:26'),(101,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','1','验证码已失效','2025-10-31 18:35:31'),(102,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-10-31 18:38:16'),(103,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','退出成功','2025-10-31 18:44:13'),(104,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-10-31 19:00:19'),(105,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-10-31 19:13:46'),(106,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','退出成功','2025-10-31 19:21:23'),(107,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-02 13:51:48'),(108,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-03 16:43:20'),(109,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-03 17:11:17'),(110,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 15:09:03'),(111,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 16:08:41'),(112,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 16:50:27'),(113,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 18:42:03'),(114,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 19:06:23'),(115,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','1','验证码已失效','2025-11-04 20:30:52'),(116,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 20:30:59'),(117,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-04 20:48:59'),(118,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-05 16:17:21'),(119,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-05 16:51:06'),(120,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-05 17:21:33'),(121,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-05 17:40:24'),(122,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-05 21:18:24'),(123,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-06 10:02:05'),(124,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-06 10:19:26'),(125,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 12:50:17'),(126,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','退出成功','2025-11-06 12:50:41'),(127,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 12:50:44'),(128,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','退出成功','2025-11-06 13:16:50'),(129,'hushan','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 13:16:59'),(130,'hushan','127.0.0.1','内网IP','Chrome 12','Windows 10','0','退出成功','2025-11-06 13:48:57'),(131,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 13:49:02'),(132,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 14:13:55'),(133,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-06 14:14:33'),(134,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-06 15:05:39'),(135,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-10 13:36:58'),(136,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-10 14:47:19'),(137,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 16:47:38'),(138,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 22:00:02'),(139,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-11 22:27:50'),(140,'0122015710106','127.0.0.1','内网IP','Chrome 14','Windows 10','1','用户不存在/密码错误','2025-11-11 22:27:52'),(141,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','1','用户不存在/密码错误','2025-11-11 22:28:04'),(142,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 22:28:30'),(143,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-11 22:41:08'),(144,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 22:41:11'),(145,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 23:19:34'),(146,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-11 23:44:26'),(147,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 23:44:34'),(148,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-11 23:50:12'),(149,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-11 23:50:19'),(150,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 10:40:59'),(151,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 11:16:21'),(152,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 12:26:23'),(153,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 13:47:44'),(154,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 20:02:25'),(155,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 21:05:00'),(156,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-12 21:25:29'),(157,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 21:26:37'),(158,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-12 21:38:12'),(159,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 21:39:59'),(160,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-12 21:57:44'),(161,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 21:57:47'),(162,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-12 22:36:54'),(163,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 22:40:16'),(164,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-12 22:48:48'),(165,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 22:48:50'),(166,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-12 22:48:51'),(167,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-13 23:08:55'),(168,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-13 23:14:38'),(169,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-13 23:14:54'),(170,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-13 23:42:20'),(171,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-13 23:56:21'),(172,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-13 23:56:22'),(173,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 00:16:40'),(174,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 00:16:54'),(175,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 00:31:10'),(176,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 00:31:11'),(177,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 00:31:26'),(178,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 22:14:38'),(179,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 22:14:42'),(180,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 22:14:45'),(181,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 22:20:05'),(182,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 22:20:21'),(183,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 22:38:02'),(184,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 22:38:09'),(185,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 22:38:10'),(186,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-14 23:17:00'),(187,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-14 23:51:42'),(188,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:10:14'),(189,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-15 10:25:54'),(190,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:25:57'),(191,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:31:22'),(192,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-15 10:31:23'),(193,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:31:26'),(194,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:31:32'),(195,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-15 10:57:41'),(196,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 10:57:46'),(197,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 19:48:54'),(198,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 21:13:43'),(199,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 21:28:02'),(200,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-15 21:28:09'),(201,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 21:28:13'),(202,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-15 21:32:06'),(203,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 21:32:17'),(204,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-15 23:48:00'),(205,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 00:07:06'),(206,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 17:40:13'),(207,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 17:51:44'),(208,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 17:51:46'),(209,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 17:51:58'),(210,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 17:58:56'),(211,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 17:59:10'),(212,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 17:59:12'),(213,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 18:12:23'),(214,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 18:39:12'),(215,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 18:44:48'),(216,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 18:44:58'),(217,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 18:52:52'),(218,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 18:53:36'),(219,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 18:59:38'),(220,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 19:01:02'),(221,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 19:13:38'),(222,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 19:13:41'),(223,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 19:50:18'),(224,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 19:50:33'),(225,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-16 20:04:42'),(226,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 20:54:15'),(227,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 21:19:00'),(228,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-16 21:58:39'),(229,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-17 17:02:29'),(230,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-17 18:11:36'),(231,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-17 19:22:10'),(232,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-17 22:03:46'),(233,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-17 22:30:36'),(234,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-17 22:30:59'),(235,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-18 09:50:29'),(236,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-18 09:56:17'),(237,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-18 09:56:23'),(238,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-18 09:56:24'),(239,'admin','127.0.0.1','内网IP','Chrome 12','Windows 10','0','登录成功','2025-11-18 09:56:38'),(240,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','退出成功','2025-11-18 10:18:49'),(241,'admin','127.0.0.1','内网IP','Chrome 14','Windows 10','0','登录成功','2025-11-18 10:19:03');
/*!40000 ALTER TABLE `sys_logininfor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint DEFAULT '0' COMMENT '父菜单ID',
  `order_num` int DEFAULT '0' COMMENT '显示顺序',
  `path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组件路径',
  `query` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '路由参数',
  `route_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '路由名称',
  `is_frame` int DEFAULT '1' COMMENT '是否为外链（0是 1否）',
  `is_cache` int DEFAULT '0' COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2011 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='菜单权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,'系统管理',0,1,'system',NULL,'','',1,0,'M','0','0','','system','admin','2025-10-31 17:51:47','',NULL,'系统管理目录'),(2,'系统监控',0,2,'monitor',NULL,'','',1,0,'M','0','0','','monitor','admin','2025-10-31 17:51:47','',NULL,'系统监控目录'),(3,'系统工具',0,3,'tool',NULL,'','',1,0,'M','0','0','','tool','admin','2025-10-31 17:51:47','',NULL,'系统工具目录'),(100,'用户管理',1,1,'user','system/user/index','','',1,0,'C','0','0','system:user:list','user','admin','2025-10-31 17:51:47','',NULL,'用户管理菜单'),(101,'角色管理',1,2,'role','system/role/index','','',1,0,'C','0','0','system:role:list','peoples','admin','2025-10-31 17:51:47','',NULL,'角色管理菜单'),(102,'菜单管理',1,3,'menu','system/menu/index','','',1,0,'C','0','0','system:menu:list','tree-table','admin','2025-10-31 17:51:47','',NULL,'菜单管理菜单'),(103,'部门管理',1,4,'dept','system/dept/index','','',1,0,'C','0','0','system:dept:list','tree','admin','2025-10-31 17:51:47','',NULL,'部门管理菜单'),(104,'岗位管理',1,5,'post','system/post/index','','',1,0,'C','0','0','system:post:list','post','admin','2025-10-31 17:51:47','',NULL,'岗位管理菜单'),(105,'字典管理',1,6,'dict','system/dict/index','','',1,0,'C','0','0','system:dict:list','dict','admin','2025-10-31 17:51:47','',NULL,'字典管理菜单'),(106,'参数设置',1,7,'config','system/config/index','','',1,0,'C','0','0','system:config:list','edit','admin','2025-10-31 17:51:47','',NULL,'参数设置菜单'),(107,'通知公告',1,8,'notice','system/notice/index','','',1,0,'C','0','0','system:notice:list','message','admin','2025-10-31 17:51:47','',NULL,'通知公告菜单'),(108,'日志管理',1,9,'log','','','',1,0,'M','0','0','','log','admin','2025-10-31 17:51:47','',NULL,'日志管理菜单'),(109,'在线用户',2,1,'online','monitor/online/index','','',1,0,'C','0','0','monitor:online:list','online','admin','2025-10-31 17:51:47','',NULL,'在线用户菜单'),(111,'数据监控',2,3,'druid','monitor/druid/index','','',1,0,'C','0','0','monitor:druid:list','druid','admin','2025-10-31 17:51:47','',NULL,'数据监控菜单'),(112,'服务监控',2,4,'server','monitor/server/index','','',1,0,'C','0','0','monitor:server:list','server','admin','2025-10-31 17:51:47','',NULL,'服务监控菜单'),(113,'缓存监控',2,5,'cache','monitor/cache/index','','',1,0,'C','0','0','monitor:cache:list','redis','admin','2025-10-31 17:51:47','',NULL,'缓存监控菜单'),(114,'缓存列表',2,6,'cacheList','monitor/cache/list','','',1,0,'C','0','0','monitor:cache:list','redis-list','admin','2025-10-31 17:51:47','',NULL,'缓存列表菜单'),(115,'表单构建',3,1,'build','tool/build/index','','',1,0,'C','0','0','tool:build:list','build','admin','2025-10-31 17:51:47','',NULL,'表单构建菜单'),(116,'代码生成',3,2,'gen','tool/gen/index','','',1,0,'C','0','0','tool:gen:list','code','admin','2025-10-31 17:51:47','',NULL,'代码生成菜单'),(117,'系统接口',3,3,'swagger','tool/swagger/index','','',1,0,'C','0','0','tool:swagger:list','swagger','admin','2025-10-31 17:51:47','',NULL,'系统接口菜单'),(500,'操作日志',108,1,'operlog','monitor/operlog/index','','',1,0,'C','0','0','monitor:operlog:list','form','admin','2025-10-31 17:51:47','',NULL,'操作日志菜单'),(501,'登录日志',108,2,'logininfor','monitor/logininfor/index','','',1,0,'C','0','0','monitor:logininfor:list','logininfor','admin','2025-10-31 17:51:47','',NULL,'登录日志菜单'),(1000,'用户查询',100,1,'','','','',1,0,'F','0','0','system:user:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1001,'用户新增',100,2,'','','','',1,0,'F','0','0','system:user:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1002,'用户修改',100,3,'','','','',1,0,'F','0','0','system:user:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1003,'用户删除',100,4,'','','','',1,0,'F','0','0','system:user:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1004,'用户导出',100,5,'','','','',1,0,'F','0','0','system:user:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1005,'用户导入',100,6,'','','','',1,0,'F','0','0','system:user:import','#','admin','2025-10-31 17:51:47','',NULL,''),(1006,'重置密码',100,7,'','','','',1,0,'F','0','0','system:user:resetPwd','#','admin','2025-10-31 17:51:47','',NULL,''),(1007,'角色查询',101,1,'','','','',1,0,'F','0','0','system:role:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1008,'角色新增',101,2,'','','','',1,0,'F','0','0','system:role:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1009,'角色修改',101,3,'','','','',1,0,'F','0','0','system:role:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1010,'角色删除',101,4,'','','','',1,0,'F','0','0','system:role:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1011,'角色导出',101,5,'','','','',1,0,'F','0','0','system:role:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1012,'菜单查询',102,1,'','','','',1,0,'F','0','0','system:menu:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1013,'菜单新增',102,2,'','','','',1,0,'F','0','0','system:menu:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1014,'菜单修改',102,3,'','','','',1,0,'F','0','0','system:menu:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1015,'菜单删除',102,4,'','','','',1,0,'F','0','0','system:menu:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1016,'部门查询',103,1,'','','','',1,0,'F','0','0','system:dept:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1017,'部门新增',103,2,'','','','',1,0,'F','0','0','system:dept:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1018,'部门修改',103,3,'','','','',1,0,'F','0','0','system:dept:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1019,'部门删除',103,4,'','','','',1,0,'F','0','0','system:dept:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1020,'岗位查询',104,1,'','','','',1,0,'F','0','0','system:post:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1021,'岗位新增',104,2,'','','','',1,0,'F','0','0','system:post:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1022,'岗位修改',104,3,'','','','',1,0,'F','0','0','system:post:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1023,'岗位删除',104,4,'','','','',1,0,'F','0','0','system:post:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1024,'岗位导出',104,5,'','','','',1,0,'F','0','0','system:post:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1025,'字典查询',105,1,'#','','','',1,0,'F','0','0','system:dict:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1026,'字典新增',105,2,'#','','','',1,0,'F','0','0','system:dict:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1027,'字典修改',105,3,'#','','','',1,0,'F','0','0','system:dict:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1028,'字典删除',105,4,'#','','','',1,0,'F','0','0','system:dict:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1029,'字典导出',105,5,'#','','','',1,0,'F','0','0','system:dict:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1030,'参数查询',106,1,'#','','','',1,0,'F','0','0','system:config:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1031,'参数新增',106,2,'#','','','',1,0,'F','0','0','system:config:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1032,'参数修改',106,3,'#','','','',1,0,'F','0','0','system:config:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1033,'参数删除',106,4,'#','','','',1,0,'F','0','0','system:config:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1034,'参数导出',106,5,'#','','','',1,0,'F','0','0','system:config:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1035,'公告查询',107,1,'#','','','',1,0,'F','0','0','system:notice:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1036,'公告新增',107,2,'#','','','',1,0,'F','0','0','system:notice:add','#','admin','2025-10-31 17:51:47','',NULL,''),(1037,'公告修改',107,3,'#','','','',1,0,'F','0','0','system:notice:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1038,'公告删除',107,4,'#','','','',1,0,'F','0','0','system:notice:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1039,'操作查询',500,1,'#','','','',1,0,'F','0','0','monitor:operlog:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1040,'操作删除',500,2,'#','','','',1,0,'F','0','0','monitor:operlog:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1041,'日志导出',500,3,'#','','','',1,0,'F','0','0','monitor:operlog:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1042,'登录查询',501,1,'#','','','',1,0,'F','0','0','monitor:logininfor:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1043,'登录删除',501,2,'#','','','',1,0,'F','0','0','monitor:logininfor:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1044,'日志导出',501,3,'#','','','',1,0,'F','0','0','monitor:logininfor:export','#','admin','2025-10-31 17:51:47','',NULL,''),(1045,'账户解锁',501,4,'#','','','',1,0,'F','0','0','monitor:logininfor:unlock','#','admin','2025-10-31 17:51:47','',NULL,''),(1046,'在线查询',109,1,'#','','','',1,0,'F','0','0','monitor:online:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1047,'批量强退',109,2,'#','','','',1,0,'F','0','0','monitor:online:batchLogout','#','admin','2025-10-31 17:51:47','',NULL,''),(1048,'单条强退',109,3,'#','','','',1,0,'F','0','0','monitor:online:forceLogout','#','admin','2025-10-31 17:51:47','',NULL,''),(1055,'生成查询',116,1,'#','','','',1,0,'F','0','0','tool:gen:query','#','admin','2025-10-31 17:51:47','',NULL,''),(1056,'生成修改',116,2,'#','','','',1,0,'F','0','0','tool:gen:edit','#','admin','2025-10-31 17:51:47','',NULL,''),(1057,'生成删除',116,3,'#','','','',1,0,'F','0','0','tool:gen:remove','#','admin','2025-10-31 17:51:47','',NULL,''),(1058,'导入代码',116,4,'#','','','',1,0,'F','0','0','tool:gen:import','#','admin','2025-10-31 17:51:47','',NULL,''),(1059,'预览代码',116,5,'#','','','',1,0,'F','0','0','tool:gen:preview','#','admin','2025-10-31 17:51:47','',NULL,''),(1060,'生成代码',116,6,'#','','','',1,0,'F','0','0','tool:gen:code','#','admin','2025-10-31 17:51:47','',NULL,''),(2000,'研发人员',0,0,'rduser','manage/rduser/index',NULL,'',1,0,'C','0','0','manage:rduser:list','rduser','admin','2025-11-05 18:08:22','admin','2025-11-06 12:53:21','研发人员菜单'),(2001,'研发人员查询',2000,1,'#','',NULL,'',1,0,'F','0','0','manage:rduser:query','#','admin','2025-11-05 18:08:22','',NULL,''),(2002,'研发人员新增',2000,2,'#','',NULL,'',1,0,'F','0','0','manage:rduser:add','#','admin','2025-11-05 18:08:23','',NULL,''),(2003,'研发人员修改',2000,3,'#','',NULL,'',1,0,'F','0','0','manage:rduser:edit','#','admin','2025-11-05 18:08:23','',NULL,''),(2004,'研发人员删除',2000,4,'#','',NULL,'',1,0,'F','0','0','manage:rduser:remove','#','admin','2025-11-05 18:08:23','',NULL,''),(2005,'产品研发',0,0,'project','manage/project/index',NULL,'',1,0,'C','0','0','manage:project:index','project','admin','2025-11-05 21:35:14','admin','2025-11-06 12:53:10','产品研发菜单'),(2006,'产品研发查询',2005,1,'#','',NULL,'',1,0,'F','0','0','manage:project:query','#','admin','2025-11-06 15:14:35','',NULL,''),(2007,'产品研发新增',2005,2,'#','',NULL,'',1,0,'F','0','0','manage:project:add','#','admin','2025-11-06 15:14:35','',NULL,''),(2008,'产品研发修改',2005,3,'#','',NULL,'',1,0,'F','0','0','manage:project:edit','#','admin','2025-11-06 15:14:35','',NULL,''),(2009,'产品研发删除',2005,4,'#','',NULL,'',1,0,'F','0','0','manage:project:remove','#','admin','2025-11-06 15:14:35','',NULL,''),(2010,'进度详情',2005,5,'',NULL,NULL,'',1,0,'F','0','0','manage:project:progress','#','admin','2025-11-16 20:13:23','admin','2025-11-17 22:32:24','');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notice`
--

DROP TABLE IF EXISTS `sys_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告标题',
  `notice_type` char(1) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob COMMENT '公告内容',
  `status` char(1) COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='通知公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notice`
--

LOCK TABLES `sys_notice` WRITE;
/*!40000 ALTER TABLE `sys_notice` DISABLE KEYS */;
INSERT INTO `sys_notice` VALUES (1,'温馨提醒：2018-07-01 若依新版本发布啦','2',_binary '新版本内容','0','admin','2025-11-05 16:48:59','',NULL,'管理员'),(2,'维护通知：2018-07-01 若依系统凌晨维护','1',_binary '维护内容','0','admin','2025-11-05 16:48:59','',NULL,'管理员');
/*!40000 ALTER TABLE `sys_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_oper_log`
--

DROP TABLE IF EXISTS `sys_oper_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_oper_log` (
  `oper_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '模块标题',
  `business_type` int DEFAULT '0' COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '请求方式',
  `operator_type` int DEFAULT '0' COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '请求参数',
  `json_result` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '返回参数',
  `status` int DEFAULT '0' COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime DEFAULT NULL COMMENT '操作时间',
  `cost_time` bigint DEFAULT '0' COMMENT '消耗时间',
  PRIMARY KEY (`oper_id`),
  KEY `idx_sys_oper_log_bt` (`business_type`),
  KEY `idx_sys_oper_log_s` (`status`),
  KEY `idx_sys_oper_log_ot` (`oper_time`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='操作日志记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_oper_log`
--

LOCK TABLES `sys_oper_log` WRITE;
/*!40000 ALTER TABLE `sys_oper_log` DISABLE KEYS */;
INSERT INTO `sys_oper_log` VALUES (100,'用户管理',2,'cn.bpeg.neri.web.controller.system.SysUserController.edit()','PUT',1,'admin','研发部门','/system/user','127.0.0.1','内网IP','{\"admin\":false,\"deptId\":105,\"email\":\"\",\"nickName\":\"胡姗\",\"params\":{},\"phonenumber\":\"19522951401\",\"postIds\":[2],\"remark\":\"测试员\",\"roleIds\":[2],\"sex\":\"0\",\"status\":\"0\",\"updateBy\":\"admin\",\"userId\":2,\"userName\":\"hushan\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-02 14:17:57',2075),(101,'菜单管理',1,'cn.bpeg.neri.web.controller.system.SysMenuController.add()','POST',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/rd_user/index\",\"createBy\":\"admin\",\"icon\":\"user\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"研发人员管理\",\"menuType\":\"C\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"path\":\"rd_user\",\"perms\":\"neri:rd_user:index\",\"status\":\"0\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-02 14:39:35',454),(102,'菜单管理',1,'cn.bpeg.neri.web.controller.system.SysMenuController.add()','POST',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/new_product/index\",\"createBy\":\"admin\",\"icon\":\"el-icon-ZoomIn\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuName\":\"新产品研发\",\"menuType\":\"C\",\"orderNum\":1,\"params\":{},\"parentId\":0,\"path\":\"new_product\",\"perms\":\"neri:new_product:index\",\"status\":\"0\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-02 14:42:28',243),(103,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/new_product/index\",\"icon\":\"el-icon-ZoomIn\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2001,\"menuName\":\"新产品研发\",\"menuType\":\"C\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"path\":\"new_product\",\"perms\":\"neri:new_product:index\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-02 14:43:01',300),(104,'参数管理',3,'cn.bpeg.neri.web.controller.system.SysConfigController.remove()','DELETE',1,'admin','研发部门','/system/config/4','127.0.0.1','内网IP','[4]',NULL,1,'内置参数【sys.account.captchaEnabled】不能删除 ','2025-11-02 14:44:10',71),(105,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user,neri_project_type,neri_project,neri_division,neri_project_division,neri_division_progress\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 15:09:42',12260),(106,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user,neri_project_type,neri_project,neri_division,neri_project_division,neri_division_progress\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 15:09:46',10496),(107,'代码生成',3,'cn.bpeg.neri.generator.controller.GenController.remove()','DELETE',1,'admin','研发部门','/tool/gen/1,2,3,4,5,6,7,8,9,10,11,12','127.0.0.1','内网IP','[1,2,3,4,5,6,7,8,9,10,11,12]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 15:10:03',927),(108,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user,neri_project_type\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 15:10:28',7374),(109,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.editSave()','PUT',1,'admin','研发部门','/tool/gen','127.0.0.1','内网IP','{\"businessName\":\"rd_user\",\"className\":\"NeriRdUser\",\"columns\":[{\"capJavaField\":\"UserId\",\"columnComment\":\"用户ID\",\"columnId\":72,\"columnName\":\"user_id\",\"columnType\":\"bigint\",\"createBy\":\"admin\",\"createTime\":\"2025-11-04 15:10:24\",\"dictType\":\"\",\"edit\":false,\"htmlType\":\"input\",\"increment\":false,\"insert\":false,\"isIncrement\":\"0\",\"isInsert\":\"0\",\"isPk\":\"1\",\"isRequired\":\"0\",\"javaField\":\"userId\",\"javaType\":\"Long\",\"list\":false,\"params\":{},\"pk\":true,\"query\":false,\"queryType\":\"EQ\",\"required\":false,\"sort\":1,\"superColumn\":false,\"tableId\":14,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"WorkId\",\"columnComment\":\"工号\",\"columnId\":73,\"columnName\":\"work_id\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-04 15:10:24\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"1\",\"javaField\":\"workId\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":true,\"sort\":2,\"superColumn\":false,\"tableId\":14,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"PositionCategory\",\"columnComment\":\"岗位类别\",\"columnId\":74,\"columnName\":\"position_category\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-04 15:10:24\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"select\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"0\",\"javaField\":\"positionCategory\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":false,\"sort\":3,\"superColumn\":false,\"tableId\":14,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"TechTitle\",\"columnComment\":\"技术职称\",\"columnId\":75,\"columnName\":\"tech_title\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-04 15:10:24\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"select\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\"','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 15:18:51',3303),(110,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user\"}',NULL,0,NULL,'2025-11-04 15:19:58',234),(111,'代码生成',6,'com.ruoyi.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 19:08:24',3990),(112,'代码生成',6,'com.ruoyi.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_division,neri_division_progress,neri_project,neri_project_division,neri_project_type\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 20:49:48',22483),(113,'代码生成',6,'com.ruoyi.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_division,neri_division_progress,neri_project,neri_project_division,neri_project_type\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 20:50:00',7372),(114,'代码生成',3,'com.ruoyi.generator.controller.GenController.remove()','DELETE',1,'admin','研发部门','/tool/gen/11,10,9,8,7,6,5,4,3,2','127.0.0.1','内网IP','[11,10,9,8,7,6,5,4,3,2]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 20:50:11',1122),(115,'代码生成',3,'com.ruoyi.generator.controller.GenController.remove()','DELETE',1,'admin','研发部门','/tool/gen/1','127.0.0.1','内网IP','[1]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 20:50:17',703),(116,'代码生成',6,'com.ruoyi.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_division,neri_division_progress,neri_project,neri_project_division,neri_project_type,neri_rd_user\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-04 20:50:37',11374),(117,'代码生成',8,'com.ruoyi.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_rd_user,neri_project_type,neri_project_division,neri_project,neri_division_progress,neri_division\"}',NULL,0,NULL,'2025-11-04 20:50:53',2139),(118,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_rduser\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 17:50:21',2016),(119,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.synchDb()','GET',1,'admin','研发部门','/tool/gen/synchDb/neri_rduser','127.0.0.1','内网IP','{}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 17:52:53',4909),(120,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.editSave()','PUT',1,'admin','研发部门','/tool/gen','127.0.0.1','内网IP','{\"businessName\":\"rduser\",\"className\":\"NeriRduser\",\"columns\":[{\"capJavaField\":\"RduserId\",\"columnComment\":\"研发人员ID\",\"columnId\":1,\"columnName\":\"rduser_id\",\"columnType\":\"bigint\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:19\",\"dictType\":\"\",\"edit\":false,\"htmlType\":\"input\",\"increment\":false,\"insert\":false,\"isIncrement\":\"0\",\"isInsert\":\"0\",\"isPk\":\"1\",\"isRequired\":\"0\",\"javaField\":\"rduserId\",\"javaType\":\"Long\",\"list\":false,\"params\":{},\"pk\":true,\"query\":false,\"queryType\":\"EQ\",\"required\":false,\"sort\":1,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-05 17:52:49\",\"usableColumn\":false},{\"capJavaField\":\"WorkId\",\"columnComment\":\"工号\",\"columnId\":2,\"columnName\":\"work_id\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:19\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"1\",\"javaField\":\"workId\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":true,\"sort\":2,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-05 17:52:50\",\"usableColumn\":false},{\"capJavaField\":\"PositionCategory\",\"columnComment\":\"岗位类别\",\"columnId\":3,\"columnName\":\"position_category\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:20\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"0\",\"javaField\":\"positionCategory\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":false,\"sort\":3,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-05 17:52:50\",\"usableColumn\":false},{\"capJavaField\":\"TechTitle\",\"columnComment\":\"技术职称\",\"columnId\":4,\"columnName\":\"tech_title\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:20\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"i','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 17:59:43',5880),(121,'研发人员管理',2,'cn.bpeg.neri.controller.NeriRduserController.edit()','PUT',1,'admin','研发部门','/manage/rduser','127.0.0.1','内网IP','{\"graduateSchool\":\"北京大学\",\"joinDate\":\"2025-11-03 00:00:00\",\"major\":\"电气专业\",\"params\":{},\"politicalStatus\":\"中共党员\",\"positionCategory\":\"软件\",\"rduserId\":4,\"techTitle\":\"高级工程师\",\"workId\":\"EMP001\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 19:02:44',248),(122,'菜单管理',1,'cn.bpeg.neri.web.controller.system.SysMenuController.add()','POST',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/prom\",\"createBy\":\"admin\",\"icon\":\"icon\",\"isFrame\":\"1\",\"menuName\":\"项目管理\",\"menuType\":\"C\",\"orderNum\":1,\"params\":{},\"path\":\"prom\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 21:35:14',130),(123,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/prom/index\",\"icon\":\"icon\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2005,\"menuName\":\"项目管理\",\"menuType\":\"C\",\"orderNum\":1,\"params\":{},\"parentId\":0,\"path\":\"prom\",\"perms\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-05 21:38:28',98),(124,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"neri/prom/index\",\"icon\":\"icon\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2005,\"menuName\":\"产品研发\",\"menuType\":\"C\",\"orderNum\":1,\"params\":{},\"parentId\":0,\"path\":\"prom\",\"perms\":\"\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 10:37:38',124),(125,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"manage/rduser/index\",\"icon\":\"rduser\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2000,\"menuName\":\"研发人员\",\"menuType\":\"C\",\"orderNum\":1,\"params\":{},\"parentId\":0,\"path\":\"rduser\",\"perms\":\"manage:rduser:list\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 12:52:23',382),(126,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"manage/project/index\",\"icon\":\"project\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2005,\"menuName\":\"产品研发\",\"menuType\":\"C\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"path\":\"project\",\"perms\":\"manage:project:index\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 12:53:10',117),(127,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"component\":\"manage/rduser/index\",\"icon\":\"rduser\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2000,\"menuName\":\"研发人员\",\"menuType\":\"C\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"path\":\"rduser\",\"perms\":\"manage:rduser:list\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 12:53:21',267),(128,'字典类型',1,'cn.bpeg.neri.web.controller.system.SysDictTypeController.add()','POST',1,'admin','研发部门','/system/dict/type','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"dictName\":\"学历\",\"dictType\":\"neri_education\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:00:39',315),(129,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"本科\",\"dictSort\":1,\"dictType\":\"neri_education\",\"dictValue\":\"本科\",\"listClass\":\"default\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:01:11',349),(130,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"硕士\",\"dictSort\":2,\"dictType\":\"neri_education\",\"dictValue\":\"硕士\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:01:31',328),(131,'字典数据',2,'cn.bpeg.neri.web.controller.system.SysDictDataController.edit()','PUT',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"default\":false,\"dictCode\":101,\"dictLabel\":\"硕士\",\"dictSort\":2,\"dictType\":\"neri_education\",\"dictValue\":\"硕士\",\"listClass\":\"default\",\"params\":{},\"status\":\"0\",\"updateBy\":\"admin\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:01:45',672),(132,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"博士\",\"dictSort\":3,\"dictType\":\"neri_education\",\"dictValue\":\"博士\",\"listClass\":\"default\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:02:00',362),(133,'字典类型',1,'cn.bpeg.neri.web.controller.system.SysDictTypeController.add()','POST',1,'admin','研发部门','/system/dict/type','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"dictName\":\"政治面貌\",\"dictType\":\"neri_political_status\",\"params\":{}}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:04:22',210),(134,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"群众\",\"dictSort\":1,\"dictType\":\"neri_political_status\",\"dictValue\":\"群众\",\"listClass\":\"default\",\"params\":{}}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:04:53',361),(135,'角色管理',2,'cn.bpeg.neri.web.controller.system.SysRoleController.dataScope()','PUT',1,'admin','研发部门','/system/role/dataScope','127.0.0.1','内网IP','{\"admin\":false,\"dataScope\":\"1\",\"deptCheckStrictly\":false,\"deptIds\":[100,101,103,104,105,102],\"flag\":false,\"menuCheckStrictly\":false,\"params\":{},\"roleId\":2,\"roleKey\":\"common\",\"roleName\":\"普通角色\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:15:55',1134),(136,'角色管理',2,'cn.bpeg.neri.web.controller.system.SysRoleController.edit()','PUT',1,'admin','研发部门','/system/role','127.0.0.1','内网IP','{\"admin\":false,\"deptCheckStrictly\":false,\"flag\":false,\"menuCheckStrictly\":false,\"menuIds\":[2005,2000,2001,2002,2003,2004],\"params\":{},\"remark\":\"普通角色\",\"roleId\":2,\"roleKey\":\"common\",\"roleName\":\"普通角色\",\"roleSort\":2,\"status\":\"0\",\"updateBy\":\"admin\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:16:30',589),(137,'用户管理',2,'cn.bpeg.neri.web.controller.system.SysUserController.resetPwd()','PUT',1,'admin','研发部门','/system/user/resetPwd','127.0.0.1','内网IP','{\"admin\":false,\"params\":{},\"updateBy\":\"admin\",\"userId\":2}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:16:44',390),(138,'研发人员管理',2,'cn.bpeg.neri.controller.NeriRduserController.edit()','PUT',1,'hushan','测试部门','/manage/rduser','127.0.0.1','内网IP','{\"birthDate\":\"2002-11-01 00:00:00\",\"education\":\"本科\",\"graduateSchool\":\"北京大学\",\"joinDate\":\"2025-11-03 00:00:00\",\"major\":\"电气专业\",\"params\":{},\"politicalStatus\":\"中共党员\",\"positionCategory\":\"软件\",\"rduserId\":4,\"techTitle\":\"高级工程师\",\"workId\":\"EMP001\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 13:17:47',206),(139,'研发人员',1,'cn.bpeg.neri.controller.NeriRduserController.add()','POST',1,'admin','研发部门','/manage/rduser','127.0.0.1','内网IP','{\"admin\":false,\"birthDate\":\"2025-11-01 00:00:00\",\"deptId\":105,\"education\":\"硕士\",\"graduateSchool\":\"清华大学\",\"joinDate\":\"2025-11-06 00:00:00\",\"major\":\"结构专业\",\"nickName\":\"李四\",\"params\":{},\"politicalStatus\":\"共青团员\",\"positionCategory\":\"硬件\",\"rduserId\":100,\"sex\":\"0\",\"techTitle\":\"初级工程师\",\"userId\":100,\"userName\":\"EMP002\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLSyntaxErrorException: Unknown column \'user_name\' in \'field list\'\r\n### The error may exist in file [C:\\Users\\hi\\Desktop\\Work\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriRduserMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriRduserMapper.insertNeriRduser-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_rduser          ( rduser_id,             user_name,             position_category,             tech_title,                          graduate_school,             major,             education,             birth_date,             join_date,             political_status )           values ( ?,             ?,             ?,             ?,                          ?,             ?,             ?,             ?,             ?,             ? )\r\n### Cause: java.sql.SQLSyntaxErrorException: Unknown column \'user_name\' in \'field list\'\n; bad SQL grammar []','2025-11-06 14:16:41',1123),(140,'研发人员',1,'cn.bpeg.neri.controller.NeriRduserController.add()','POST',1,'admin','研发部门','/manage/rduser','127.0.0.1','内网IP','{\"admin\":false,\"birthDate\":\"2025-11-01 00:00:00\",\"deptId\":105,\"education\":\"硕士\",\"graduateSchool\":\"清华大学\",\"joinDate\":\"2025-11-06 00:00:00\",\"major\":\"结构专业\",\"nickName\":\"李四\",\"params\":{},\"politicalStatus\":\"共青团员\",\"positionCategory\":\"硬件\",\"rduserId\":101,\"sex\":\"0\",\"techTitle\":\"初级工程师\",\"userId\":101,\"userName\":\"EMP002\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 14:18:14',747),(141,'研发人员',3,'cn.bpeg.neri.controller.NeriRduserController.remove()','DELETE',1,'admin','研发部门','/manage/rduser/101','127.0.0.1','内网IP','[101]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 14:52:21',211),(142,'用户管理',3,'cn.bpeg.neri.web.controller.system.SysUserController.remove()','DELETE',1,'admin','研发部门','/system/user/101','127.0.0.1','内网IP','[101]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 14:53:01',913),(143,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.synchDb()','GET',1,'admin','研发部门','/tool/gen/synchDb/neri_rduser','127.0.0.1','内网IP','{}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 15:06:16',2844),(144,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.editSave()','PUT',1,'admin','研发部门','/tool/gen','127.0.0.1','内网IP','{\"businessName\":\"rduser\",\"className\":\"NeriRduser\",\"columns\":[{\"capJavaField\":\"RduserId\",\"columnComment\":\"\",\"columnId\":1,\"columnName\":\"rduser_id\",\"columnType\":\"bigint\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:19\",\"dictType\":\"\",\"edit\":false,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isPk\":\"1\",\"isRequired\":\"0\",\"javaField\":\"rduserId\",\"javaType\":\"Long\",\"list\":false,\"params\":{},\"pk\":true,\"query\":false,\"queryType\":\"EQ\",\"required\":false,\"sort\":1,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-06 15:06:13\",\"usableColumn\":false},{\"capJavaField\":\"PositionCategory\",\"columnComment\":\"\",\"columnId\":3,\"columnName\":\"position_category\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:20\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"0\",\"javaField\":\"positionCategory\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":false,\"sort\":2,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-06 15:06:14\",\"usableColumn\":false},{\"capJavaField\":\"TechTitle\",\"columnComment\":\"\",\"columnId\":4,\"columnName\":\"tech_title\",\"columnType\":\"varchar(50)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:20\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"0\",\"javaField\":\"techTitle\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":false,\"sort\":3,\"superColumn\":false,\"tableId\":1,\"updateBy\":\"\",\"updateTime\":\"2025-11-06 15:06:14\",\"usableColumn\":false},{\"capJavaField\":\"GraduateSchool\",\"columnComment\":\"\",\"columnId\":6,\"columnName\":\"graduate_school\",\"columnType\":\"varchar(100)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-05 17:50:20\",\"dictType\":\"\",\"edit\":true,\"htmlType','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 15:07:05',2392),(145,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_project\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 15:07:45',2701),(146,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.editSave()','PUT',1,'admin','研发部门','/tool/gen','127.0.0.1','内网IP','{\"businessName\":\"project\",\"className\":\"NeriProject\",\"columns\":[{\"capJavaField\":\"ProjectId\",\"columnComment\":\"项目ID\",\"columnId\":12,\"columnName\":\"project_id\",\"columnType\":\"int\",\"createBy\":\"admin\",\"createTime\":\"2025-11-06 15:07:43\",\"dictType\":\"\",\"edit\":false,\"htmlType\":\"input\",\"increment\":true,\"insert\":false,\"isIncrement\":\"1\",\"isInsert\":\"0\",\"isPk\":\"1\",\"isRequired\":\"0\",\"javaField\":\"projectId\",\"javaType\":\"Integer\",\"list\":false,\"params\":{},\"pk\":true,\"query\":false,\"queryType\":\"EQ\",\"required\":false,\"sort\":1,\"superColumn\":false,\"tableId\":2,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"ProjectName\",\"columnComment\":\"项目名称\",\"columnId\":13,\"columnName\":\"project_name\",\"columnType\":\"varchar(200)\",\"createBy\":\"admin\",\"createTime\":\"2025-11-06 15:07:43\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"1\",\"javaField\":\"projectName\",\"javaType\":\"String\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"LIKE\",\"required\":true,\"sort\":2,\"superColumn\":false,\"tableId\":2,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"ProjectTypeId\",\"columnComment\":\"项目类型ID\",\"columnId\":14,\"columnName\":\"project_type_id\",\"columnType\":\"int\",\"createBy\":\"admin\",\"createTime\":\"2025-11-06 15:07:43\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"select\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk\":\"0\",\"isQuery\":\"1\",\"isRequired\":\"1\",\"javaField\":\"projectTypeId\",\"javaType\":\"Integer\",\"list\":true,\"params\":{},\"pk\":false,\"query\":true,\"queryType\":\"EQ\",\"required\":true,\"sort\":3,\"superColumn\":false,\"tableId\":2,\"updateBy\":\"\",\"usableColumn\":false},{\"capJavaField\":\"LeaderId\",\"columnComment\":\"项目负责人\",\"columnId\":15,\"columnName\":\"leader_id\",\"columnType\":\"bigint\",\"createBy\":\"admin\",\"createTime\":\"2025-11-06 15:07:43\",\"dictType\":\"\",\"edit\":true,\"htmlType\":\"input\",\"increment\":false,\"insert\":true,\"isEdit\":\"1\",\"isIncrement\":\"0\",\"isInsert\":\"1\",\"isList\":\"1\",\"isPk','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-06 15:12:32',2751),(147,'研发人员',1,'cn.bpeg.neri.controller.NeriRduserController.add()','POST',1,'admin','研发部门','/manage/rduser','127.0.0.1','内网IP','{\"admin\":false,\"birthDate\":\"2025-11-06 00:00:00\",\"deptId\":102,\"education\":\"硕士\",\"graduateSchool\":\"武汉理工大学\",\"joinDate\":\"2025-11-10 00:00:00\",\"major\":\"信息工程\",\"nickName\":\"李四\",\"params\":{},\"politicalStatus\":\"共青团员\",\"positionCategory\":\"软件\",\"rduserId\":102,\"sex\":\"1\",\"techTitle\":\"中级工程师\",\"userId\":102,\"userName\":\"EMP002\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-10 14:03:27',1105),(148,'用户头像',2,'cn.bpeg.neri.web.controller.system.SysProfileController.avatar()','POST',1,'admin','研发部门','/system/user/profile/avatar','127.0.0.1','内网IP','',NULL,1,'D:\\neri\\uploadPath\\avatar\\2025\\11\\10\\af840c3e3b9a460bbaad3edc158ed849.png','2025-11-10 14:11:08',286),(149,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"params\":{},\"projectId\":1,\"projectName\":\"测试\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 12:44:07',277),(150,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/1','127.0.0.1','内网IP','[1]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 12:44:40',96),(151,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"params\":{},\"projectId\":2,\"projectName\":\"测试\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 12:51:27',161),(152,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/2','127.0.0.1','内网IP','[2]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 12:52:17',71),(153,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"params\":{},\"projectId\":3,\"projectName\":\"测试\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 13:37:14',169),(154,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/3','127.0.0.1','内网IP','[3]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 13:37:20',82),(155,'产品研发',1,'cn.bpeg.neri.controller.NeriProTypeController.add()','POST',1,'admin','研发部门','/manage/type/project','127.0.0.1','内网IP','{\"params\":{}}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLSyntaxErrorException: Unknown column \'pro_type_id\' in \'field list\'\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProTypeMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProTypeMapper.insertNeriProType-Inline\r\n### The error occurred while setting parameters\r\n### SQL: INSERT INTO neri_project_type         (          pro_type_id, name, description      )         values         (?, ?)\r\n### Cause: java.sql.SQLSyntaxErrorException: Unknown column \'pro_type_id\' in \'field list\'\n; bad SQL grammar []','2025-11-12 13:45:51',263),(156,'产品研发',1,'cn.bpeg.neri.controller.NeriProTypeController.add()','POST',1,'admin','研发部门','/manage/type/project','127.0.0.1','内网IP','{\"params\":{}}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProTypeMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProTypeMapper.insertNeriProType-Inline\r\n### The error occurred while setting parameters\r\n### SQL: INSERT INTO neri_project_type         (          name, description      )         values         (?, ?)\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\n; Column \'name\' cannot be null','2025-11-12 13:47:51',167),(157,'产品研发',1,'cn.bpeg.neri.controller.NeriProTypeController.add()','POST',1,'admin','研发部门','/manage/type/project','127.0.0.1','内网IP','{\"params\":{}}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProTypeMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProTypeMapper.insertNeriProType-Inline\r\n### The error occurred while setting parameters\r\n### SQL: INSERT INTO neri_project_type         (          name, description      )         values         (?, ?)\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\n; Column \'name\' cannot be null','2025-11-12 20:04:33',391),(158,'产品研发',1,'cn.bpeg.neri.controller.NeriProTypeController.add()','POST',1,'admin','研发部门','/manage/type/project','127.0.0.1','内网IP','{\"params\":{}}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProTypeMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProTypeMapper.insertNeriProType-Inline\r\n### The error occurred while setting parameters\r\n### SQL: INSERT INTO neri_project_type         (          name, description      )         values         (?, ?)\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Column \'name\' cannot be null\n; Column \'name\' cannot be null','2025-11-12 21:06:32',196),(159,'产品研发',1,'cn.bpeg.neri.controller.NeriProTypeController.add()','POST',1,'admin','研发部门','/manage/type/project','127.0.0.1','内网IP','{\"description\":\"测试测试\",\"name\":\"测试\",\"params\":{},\"proTypeId\":1}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-12 21:20:23',60),(160,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-14 00:00:00\",\"leaderId\":105,\"params\":{},\"projectName\":\"测试项目\",\"specialistId\":105,\"startDate\":\"2025-11-13 00:00:00\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProjectMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProjectMapper.insertNeriProject-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_project          ( project_name,                          leader_id,             specialist_id,             start_date,             end_date )           values ( ?,                          ?,             ?,             ?,             ? )\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\n; Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))','2025-11-13 18:44:37',552),(161,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"leaderId\":105,\"params\":{},\"projectName\":\"测试项目\",\"specialistId\":105,\"startDate\":\"2025-11-13 00:00:00\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProjectMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProjectMapper.insertNeriProject-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_project          ( project_name,                          leader_id,             specialist_id,             start_date )           values ( ?,                          ?,             ?,             ? )\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\n; Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))','2025-11-13 23:56:51',547),(162,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-15 00:00:00\",\"leaderId\":3,\"params\":{},\"projectName\":\"测试项目\",\"specialistId\":3,\"startDate\":\"2025-11-14 00:00:00\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProjectMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProjectMapper.insertNeriProject-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_project          ( project_name,                          leader_id,             specialist_id,             start_date,             end_date )           values ( ?,                          ?,             ?,             ?,             ? )\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\n; Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))','2025-11-14 00:04:02',140),(163,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-15 00:00:00\",\"leaderId\":1,\"params\":{},\"projectName\":\"测试项目\",\"specialistId\":1,\"startDate\":\"2025-11-14 00:00:00\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProjectMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProjectMapper.insertNeriProject-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_project          ( project_name,                          leader_id,             specialist_id,             start_date,             end_date )           values ( ?,                          ?,             ?,             ?,             ? )\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))\n; Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_2` FOREIGN KEY (`leader_id`) REFERENCES `neri_rduser` (`rduser_id`))','2025-11-14 00:05:48',161),(164,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-15 00:00:00\",\"leaderId\":102,\"params\":{},\"projectName\":\"测试项目\",\"specialistId\":103,\"startDate\":\"2025-11-14 00:00:00\"}',NULL,1,'\r\n### Error updating database.  Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_3` FOREIGN KEY (`specialist_id`) REFERENCES `neri_rduser` (`rduser_id`))\r\n### The error may exist in file [E:\\Projects\\GitHub\\BPEG-NERI-RD-Admin-System\\neri-manage\\target\\classes\\mapper\\NeriProjectMapper.xml]\r\n### The error may involve cn.bpeg.neri.mapper.NeriProjectMapper.insertNeriProject-Inline\r\n### The error occurred while setting parameters\r\n### SQL: insert into neri_project          ( project_name,                          leader_id,             specialist_id,             start_date,             end_date )           values ( ?,                          ?,             ?,             ?,             ? )\r\n### Cause: java.sql.SQLIntegrityConstraintViolationException: Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_3` FOREIGN KEY (`specialist_id`) REFERENCES `neri_rduser` (`rduser_id`))\n; Cannot add or update a child row: a foreign key constraint fails (`neri_rd`.`neri_project`, CONSTRAINT `neri_project_ibfk_3` FOREIGN KEY (`specialist_id`) REFERENCES `neri_rduser` (`rduser_id`))','2025-11-14 00:19:46',141),(165,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-15 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":9,\"projectName\":\"测试项目\",\"specialistId\":4,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 00:32:01',139),(166,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/9','127.0.0.1','内网IP','[9]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 17:51:23',92),(167,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":10,\"projectName\":\"测试项目\",\"specialistId\":102,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 17:52:07',191),(168,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"leaderId\":4,\"params\":{},\"projectId\":11,\"projectName\":\"项目测试\",\"specialistId\":4,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:40:51',231),(169,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"leaderId\":4,\"params\":{},\"projectId\":12,\"projectName\":\"1\",\"specialistId\":4,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:43:43',134),(170,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/12','127.0.0.1','内网IP','[12]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:45:46',67),(171,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/11','127.0.0.1','内网IP','[11]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:45:49',59),(172,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"leaderId\":4,\"params\":{},\"projectId\":13,\"projectName\":\"测试项目\",\"specialistId\":102,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:46:22',127),(173,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/10,13','127.0.0.1','内网IP','[10,13]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:52:46',75),(174,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-15 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":14,\"projectName\":\"测试项目\",\"projectTypeId\":1,\"specialistId\":4,\"startDate\":\"2025-11-14 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-14 22:54:48',164),(175,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-16 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":15,\"projectName\":\"项目测试\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-15 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 21:54:28',344),(176,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":16,\"projectName\":\"测试\",\"projectTypeId\":1,\"specialistId\":4,\"startDate\":\"2025-11-15 00:00:00\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:04:51',579),(177,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/16,15','127.0.0.1','内网IP','[16,15]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:14:29',187),(178,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/15/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251115223930A008.pdf,/profile/upload/2025/11/15/公共数据授权运营发展洞察_20251115223930A009.pdf\",\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":17,\"projectName\":\"测试\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-15 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/15/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251115223930A010.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:39:30',299),(179,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/14','127.0.0.1','内网IP','[14]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:40:22',96),(180,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/15/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251115224251A011.pdf,/profile/upload/2025/11/15/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251115224251A012.pdf\",\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":18,\"projectName\":\"测试时\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-14 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/15/《公共数据资源授权运营实施规范（试行）》.pdf_20251115224251A013.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:42:51',284),(181,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/15/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251115224902A014.pdf\",\"endDate\":\"2025-11-18 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":19,\"projectName\":\"测试测试\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-15 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/15/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251115224902A015.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:49:02',229),(182,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/19','127.0.0.1','内网IP','[19]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-15 22:49:33',103),(183,'产品研发',2,'cn.bpeg.neri.controller.NeriProjectController.edit()','PUT',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"\",\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":17,\"projectName\":\"测试\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-15 00:00:00\",\"tenderFile\":\"\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 00:06:29',124),(184,'产品研发',3,'cn.bpeg.neri.controller.NeriProjectController.remove()','DELETE',1,'admin','研发部门','/manage/project/17','127.0.0.1','内网IP','[17]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 00:07:15',119),(185,'产品研发',2,'cn.bpeg.neri.controller.NeriProjectController.edit()','PUT',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/15/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251115224251A011.pdf\",\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":18,\"projectName\":\"测试时\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-14 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/15/《公共数据资源授权运营实施规范（试行）》.pdf_20251115224251A013.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 00:07:19',121),(186,'产品研发',2,'cn.bpeg.neri.controller.NeriProjectController.edit()','PUT',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/15/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251115224251A011.pdf,/profile/upload/2025/11/16/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251116000835A001.pdf\",\"endDate\":\"2025-11-21 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":18,\"projectName\":\"测试时\",\"projectTypeId\":1,\"specialistId\":102,\"startDate\":\"2025-11-14 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/15/《公共数据资源授权运营实施规范（试行）》.pdf_20251115224251A013.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 00:08:35',151),(187,'代码生成',6,'cn.bpeg.neri.generator.controller.GenController.importTableSave()','POST',1,'admin','研发部门','/tool/gen/importTable','127.0.0.1','内网IP','{\"tables\":\"neri_division,neri_division_progress,neri_project_division\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 19:15:27',1045),(188,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_division\"}',NULL,0,NULL,'2025-11-16 19:17:49',391),(189,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_division_progress\"}',NULL,0,NULL,'2025-11-16 19:19:32',94),(190,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_project_division\"}',NULL,0,NULL,'2025-11-16 19:19:34',45),(191,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_division\"}',NULL,0,NULL,'2025-11-16 19:53:03',214),(192,'菜单管理',1,'cn.bpeg.neri.web.controller.system.SysMenuController.add()','POST',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"createBy\":\"admin\",\"menuName\":\"进度详情\",\"menuType\":\"F\",\"orderNum\":5,\"params\":{},\"parentId\":2005,\"perms\":\"manage:project:process\",\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 20:13:23',93),(193,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.synchDb()','GET',1,'admin','研发部门','/tool/gen/synchDb/neri_project_division','127.0.0.1','内网IP','{}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:13:08',269),(194,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_project_division\"}',NULL,0,NULL,'2025-11-16 21:13:10',170),(195,'代码生成',2,'cn.bpeg.neri.generator.controller.GenController.synchDb()','GET',1,'admin','研发部门','/tool/gen/synchDb/neri_division_progress','127.0.0.1','内网IP','{}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:13:38',684),(196,'代码生成',8,'cn.bpeg.neri.generator.controller.GenController.batchGenCode()','GET',1,'admin','研发部门','/tool/gen/batchGenCode','127.0.0.1','内网IP','{\"tables\":\"neri_division_progress\"}',NULL,0,NULL,'2025-11-16 21:13:39',51),(197,'字典类型',1,'cn.bpeg.neri.web.controller.system.SysDictTypeController.add()','POST',1,'admin','研发部门','/system/dict/type','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"dictName\":\"专业\",\"dictType\":\"major_name\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:49:09',121),(198,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"电气一次\",\"dictSort\":0,\"dictType\":\"major_name\",\"dictValue\":\"1\",\"listClass\":\"default\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:50:01',656),(199,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"电气二次\",\"dictSort\":1,\"dictType\":\"major_name\",\"dictValue\":\"2\",\"listClass\":\"default\",\"params\":{}}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:50:18',408),(200,'字典数据',1,'cn.bpeg.neri.web.controller.system.SysDictDataController.add()','POST',1,'admin','研发部门','/system/dict/data','127.0.0.1','内网IP','{\"createBy\":\"admin\",\"default\":false,\"dictLabel\":\"结构\",\"dictSort\":1,\"dictType\":\"major_name\",\"dictValue\":\"3\",\"listClass\":\"default\",\"params\":{},\"status\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:50:37',731),(201,'字典类型',3,'cn.bpeg.neri.web.controller.system.SysDictDataController.remove()','DELETE',1,'admin','研发部门','/system/dict/data/108','127.0.0.1','内网IP','[108]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:50:59',140),(202,'字典类型',3,'cn.bpeg.neri.web.controller.system.SysDictDataController.remove()','DELETE',1,'admin','研发部门','/system/dict/data/107','127.0.0.1','内网IP','[107]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:51:01',145),(203,'字典类型',3,'cn.bpeg.neri.web.controller.system.SysDictDataController.remove()','DELETE',1,'admin','研发部门','/system/dict/data/109','127.0.0.1','内网IP','[109]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:51:02',135),(204,'字典类型',3,'cn.bpeg.neri.web.controller.system.SysDictTypeController.remove()','DELETE',1,'admin','研发部门','/system/dict/type/102','127.0.0.1','内网IP','[102]','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-16 21:51:08',132),(205,'项目类型',1,'cn.bpeg.neri.controller.NeriProjectTypeController.add()','POST',1,'admin','研发部门','/manage/project/type','127.0.0.1','内网IP','{\"description\":\"测试测试\",\"name\":\"测试类型\",\"params\":{},\"projectTypeId\":2}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-17 22:04:19',231),(206,'项目类型',1,'cn.bpeg.neri.controller.NeriProjectTypeController.add()','POST',1,'admin','研发部门','/manage/project/type','127.0.0.1','内网IP','{\"description\":\"\",\"name\":\"项目类型\",\"params\":{},\"projectTypeId\":3}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-17 22:07:02',199),(207,'项目类型',1,'cn.bpeg.neri.controller.NeriProjectTypeController.add()','POST',1,'admin','研发部门','/manage/project/type','127.0.0.1','内网IP','{\"description\":\"\",\"name\":\"测试下\",\"params\":{},\"projectTypeId\":4}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-17 22:07:43',158),(208,'菜单管理',2,'cn.bpeg.neri.web.controller.system.SysMenuController.edit()','PUT',1,'admin','研发部门','/system/menu','127.0.0.1','内网IP','{\"children\":[],\"icon\":\"#\",\"isCache\":\"0\",\"isFrame\":\"1\",\"menuId\":2010,\"menuName\":\"进度详情\",\"menuType\":\"F\",\"orderNum\":5,\"params\":{},\"parentId\":2005,\"path\":\"\",\"perms\":\"manage:project:progress\",\"status\":\"0\",\"updateBy\":\"admin\",\"visible\":\"0\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-17 22:32:24',252),(209,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/18/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251118095658A001.pdf,/profile/upload/2025/11/18/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251118095658A002.pdf\",\"endDate\":\"2025-11-26 00:00:00\",\"leaderId\":4,\"params\":{},\"projectId\":20,\"projectName\":\"测试项目\",\"projectTypeId\":2,\"specialistId\":102,\"startDate\":\"2025-11-18 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/18/《公共数据资源登记管理暂行办法》.pdf_20251118095658A003.pdf,/profile/upload/2025/11/18/《公共数据资源授权运营实施规范（试行）》.pdf_20251118095658A004.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-18 09:56:58',194),(210,'部门管理',2,'cn.bpeg.neri.web.controller.system.SysDeptController.edit()','PUT',1,'admin','研发部门','/system/dept','127.0.0.1','内网IP','{\"children\":[],\"deptId\":100,\"deptName\":\"新能源研发总院\",\"email\":\"ry@qq.com\",\"orderNum\":0,\"params\":{},\"parentId\":0,\"phone\":\"15888888888\",\"status\":\"0\",\"updateBy\":\"admin\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-18 09:59:08',849),(211,'项目类型',1,'cn.bpeg.neri.controller.NeriProjectTypeController.add()','POST',1,'admin','研发部门','/manage/project/type','127.0.0.1','内网IP','{\"description\":\"\",\"name\":\"项目测试\",\"params\":{},\"projectTypeId\":5}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-18 10:00:12',103),(212,'产品研发',1,'cn.bpeg.neri.controller.NeriProjectController.add()','POST',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/18/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251118100052A005.pdf,/profile/upload/2025/11/18/中共中央办公厅 国务院办公厅关于加快公共数据资源开发利用的意见_20251118100052A006.pdf\",\"leaderId\":102,\"params\":{},\"projectId\":21,\"projectName\":\"测试\",\"projectTypeId\":3,\"specialistId\":4,\"startDate\":\"2025-11-18 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/18/公共数据授权运营发展洞察_20251118100052A007.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-18 10:00:52',144),(213,'产品研发',2,'cn.bpeg.neri.controller.NeriProjectController.edit()','PUT',1,'admin','研发部门','/manage/project','127.0.0.1','内网IP','{\"contractFile\":\"/profile/upload/2025/11/18/国家发展改革委 国家数据局关于印发《公共数据资源授权运营实施规范（试行）》的通知_20251118100052A005.pdf\",\"leaderId\":102,\"params\":{},\"projectId\":21,\"projectName\":\"测试\",\"projectTypeId\":3,\"specialistId\":4,\"startDate\":\"2025-11-18 00:00:00\",\"tenderFile\":\"/profile/upload/2025/11/18/公共数据授权运营发展洞察_20251118100052A007.pdf\"}','{\"msg\":\"操作成功\",\"code\":200}',0,NULL,'2025-11-18 10:01:20',60);
/*!40000 ALTER TABLE `sys_oper_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_post`
--

DROP TABLE IF EXISTS `sys_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_post` (
  `post_id` bigint NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `post_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位名称',
  `post_sort` int NOT NULL COMMENT '显示顺序',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='岗位信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_post`
--

LOCK TABLES `sys_post` WRITE;
/*!40000 ALTER TABLE `sys_post` DISABLE KEYS */;
INSERT INTO `sys_post` VALUES (1,'ceo','董事长',1,'0','admin','2025-10-31 17:51:47','',NULL,''),(2,'se','项目经理',2,'0','admin','2025-10-31 17:51:47','',NULL,''),(3,'hr','软件',3,'0','admin','2025-10-31 17:51:47','',NULL,''),(4,'user','硬件',4,'0','admin','2025-10-31 17:51:47','',NULL,'');
/*!40000 ALTER TABLE `sys_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `role_id` bigint NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) DEFAULT '1' COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) DEFAULT '1' COMMENT '部门树选择项是否关联显示',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','admin',1,'1',1,1,'0','0','admin','2025-10-31 17:51:47','',NULL,'超级管理员'),(2,'普通角色','common',2,'1',0,0,'0','0','admin','2025-10-31 17:51:47','admin','2025-11-06 13:16:29','普通角色');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_dept`
--

DROP TABLE IF EXISTS `sys_role_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_dept` (
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `dept_id` bigint NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`role_id`,`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色和部门关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_dept`
--

LOCK TABLES `sys_role_dept` WRITE;
/*!40000 ALTER TABLE `sys_role_dept` DISABLE KEYS */;
INSERT INTO `sys_role_dept` VALUES (2,100),(2,101),(2,102),(2,103),(2,104),(2,105);
/*!40000 ALTER TABLE `sys_role_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_menu`
--

DROP TABLE IF EXISTS `sys_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `menu_id` bigint NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色和菜单关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_menu`
--

LOCK TABLES `sys_role_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_menu` DISABLE KEYS */;
INSERT INTO `sys_role_menu` VALUES (2,2000),(2,2001),(2,2002),(2,2003),(2,2004),(2,2005);
/*!40000 ALTER TABLE `sys_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` bigint DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户账号',
  `nick_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '头像地址',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '密码',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '账号状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '最后登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '最后登录时间',
  `pwd_update_date` datetime DEFAULT NULL COMMENT '密码最后更新时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,103,'admin','管理员','00','',NULL,'0','','$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2','0','0','127.0.0.1','2025-11-18 10:19:04','2025-10-31 17:51:47','admin','2025-10-31 17:51:47','',NULL,'管理员'),(2,105,'hushan','胡姗','00','','19522951401','0','','$2a$10$SI/GsiN2.pmQlfl29/nqsubOf.dnoXCAjOX70APJCao6oK9fLGVQa','0','0','127.0.0.1','2025-11-06 13:17:03','2025-11-06 13:16:44','admin','2025-10-31 17:51:47','admin','2025-11-06 13:16:44','测试员'),(3,105,'lijiaming','李佳明','00','','','0','','','0','0','',NULL,NULL,'',NULL,'',NULL,'测试员'),(4,103,'EMP001','张三','00','','','0','','','0','0','',NULL,NULL,'',NULL,'',NULL,NULL),(102,102,'EMP002','李四','00','','','1','','','0','0','',NULL,NULL,'','2025-11-10 14:03:26','',NULL,NULL);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_post`
--

DROP TABLE IF EXISTS `sys_user_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_post` (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `post_id` bigint NOT NULL COMMENT '岗位ID',
  PRIMARY KEY (`user_id`,`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户与岗位关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_post`
--

LOCK TABLES `sys_user_post` WRITE;
/*!40000 ALTER TABLE `sys_user_post` DISABLE KEYS */;
INSERT INTO `sys_user_post` VALUES (1,1),(2,2);
/*!40000 ALTER TABLE `sys_user_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户和角色关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES (1,1),(2,2);
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'neri_rd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-20 17:48:54
